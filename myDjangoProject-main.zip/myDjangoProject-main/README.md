<h2># MyDjangoProject </h2>
To run the Project on your local machine go to the myDjangoProject folder (where the manage.py file is) and execute:
<ul>
  <li><span style="background-color:#EEEEEE; font-family:Consolas,Monaco,Lucida Console,Liberation Mono,DejaVu Sans Mono,Bitstream Vera Sans Mono,Courier New;">python manage.py runserver</span> (in linux) or</li>
  <li><span style="background-color:#EEEEEE; font-family:Consolas,Monaco,Lucida Console,Liberation Mono,DejaVu Sans Mono,Bitstream Vera Sans Mono,Courier New;">py manage.py runserver</span> (in Windows)</li>
</ul>
in the console, then open to your webbrowser and enter the url http://localhost:8000/index/ to go to the main page.
